#!/usr/bin/env bash

set -e
[ $(id -u) -ne 0 ] && echo "try: sudo $0" >&2 && exit 1


apt-get update && apt-get install -y parprouted dhcp-helper
grep '^denyinterfaces eth0' /etc/dhcpcd.conf || echo denyinterfaces eth0 | tee -a /etc/dhcpcd.conf 
sed -i -e 's/^#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf

systemctl stop dhcp-helper
systemctl enable dhcp-helper
echo DHCPHELPER_OPTS=\"-b wlan0\" | tee /etc/default/dhcp-helper

# Avahi: enable-reflector=yes
sed -i -e 's/^#enable-reflector=no/enable-reflector=yes/' /etc/avahi/avahi-daemon.conf

cat <<'EOF' >/etc/systemd/system/parprouted.service
[Unit]
Description=proxy arp routing service
Documentation=https://qiita.com/mt08/items/00102a6d513194ea5a92
After=dhcpcd.service

[Service]
Type=forking
# Restart until wlan0 gained carrier
Restart=on-failure
RestartSec=5
TimeoutStartSec=30
ExecStartPre=/bin/echo 'parprouted: wlan0 is online'
# clone the dhcp-allocated IP to eth0 so dhcp-helper will relay for the correct subnet
ExecStartPre=/sbin/ip addr flush dev eth0
ExecStartPre=/bin/bash -c '/sbin/ip addr add $(/sbin/ip -4 addr show wlan0 | /bin/grep -Po "\\d+\\.\\d+\\.\\d+\\.\\d+\/")32 dev eth0'
ExecStartPre=/sbin/ip link set dev eth0 up
ExecStartPre=/sbin/ip link set wlan0 promisc on

#         v minus sign
ExecStart=-/usr/sbin/parprouted eth0 wlan0

ExecStopPost=/sbin/ip link set wlan0 promisc off
ExecStopPost=/sbin/ip link set dev eth0 down
ExecStopPost=/sbin/ip addr flush dev eth0

[Install]
WantedBy=multi-user.target
EOF
systemctl enable parprouted.service

systemctl daemon-reload
reboot
